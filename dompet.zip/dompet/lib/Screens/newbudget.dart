import 'dart:convert';

import 'package:dompet/mainpage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../checklogin.dart';

class NewBudget extends StatefulWidget {
  const NewBudget({super.key});

  @override
  State<NewBudget> createState() => _NewBudgetState();
}

class _NewBudgetState extends State<NewBudget> {
  TextEditingController amount = TextEditingController();
  TextEditingController title = TextEditingController();
  TextEditingController desc = TextEditingController();
  TextEditingController freq = TextEditingController();
  TextEditingController reminder = TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    username();
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
        title: Text('Add a new budget',style: TextStyle(color: Colors.black,fontSize: 22),),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [

            Padding(
              padding: const EdgeInsets.only(left: 18.0,top: 18),
              child: Container(
                  alignment: Alignment.topLeft,
                  child: Text('Enter amount',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
              child: TextField(
                keyboardType: TextInputType.number,
                controller: amount,
                cursorColor: Colors.black,
                onChanged: (amount)
                {
                  setState(() {

                  });
                },
                style: TextStyle(color: Colors.black,fontSize: 18),
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.transparent,),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.transparent,),
                    borderRadius: BorderRadius.circular(24),

                  ),
                  hintText: '  Eg. \$10.00.00',
                  fillColor: Color(0xffF8F7F1),
                  filled: true,
                  hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                ),),


            ),

            SizedBox(
              height: 20,
            ),

            Container(
              color: Color(0xffF8F7F1),
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0,left: 20,bottom: 20),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Budget details',style: TextStyle(fontSize: 20,color: Colors.black54,fontWeight: FontWeight.w500),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Title',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        onChanged: (title)
                        {
                          setState(() {

                          });
                        },
                        controller: title,
                        cursorColor: Colors.black,
                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Eg. College Laptop',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),


                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Description',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        controller: desc,
                        cursorColor: Colors.black,
                        onChanged: (desc)
                        {
                          setState(() {

                          });
                        },

                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Eg. Give more detail to your plan',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),


                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Frequency of budget',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        keyboardType: TextInputType.number,
                        controller: freq,
                        cursorColor: Colors.black,
                        onChanged: (freq)
                        {
                          setState(() {

                          });
                        },

                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  1',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),


                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Set a reminder',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        controller: reminder,
                        cursorColor: Colors.black,
                        onChanged: (reminder)
                        {
                          setState(() {

                          });
                        },

                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Yes',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),
                    ),


                    if (amount.text.isEmpty&&
                        title.text.isEmpty&&
                        desc.text.isEmpty&&
                        freq.text.isEmpty&&
                        reminder.text.isEmpty) Padding(
                      padding: const EdgeInsets.only(top: 35.0,left: 20,right: 20,bottom: 40),
                      child: Container(
                        width: double.infinity,
                        height: 55,
                        decoration: BoxDecoration(
                          color: Color(0xff9DAEE2),
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child:
                        Center(
                            child: Text('Continue',style: TextStyle(fontSize: 22,color: Colors.white,fontWeight: FontWeight.w500),)),
                      ),
                    ) else Padding(
                      padding: const EdgeInsets.only(top: 35.0,left: 20,right: 20,bottom: 40),
                      child: Container(
                        width: double.infinity,
                        height: 55,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            InkWell(
                              onTap: ()
                              async {
                                SharedPreferences prefbudget = await SharedPreferences.getInstance();
                              if(prefbudget.getString('budget')==null)
                              {
                                print("empty");
                                Fluttertoast.showToast(msg: 'Budget does not exist');

                                return;
                              }
                              var encodedMap = prefbudget.getString('budget');
                              Map<String,dynamic> decodedMap = json.decode(encodedMap!);
                              print(decodedMap);

                              if(title.text.isNotEmpty)
                                {
                                  if(title.text==decodedMap['title'])
                                    {
                                      SharedPreferences prefbudget = await SharedPreferences.getInstance();
                                      prefbudget.clear();
                                      Fluttertoast.showToast(msg: 'The whole Budget has been deleted');
                                    }
                                  else
                                    {
                                      Fluttertoast.showToast(msg: 'Title does not match. Please enter correct title');

                                    }

                                }
                              else
                                {
                                  Fluttertoast.showToast(msg: 'Must enter title');
                                }
                              },
                              child: Container(
                                  width: 155,
                                  height: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(22),
                                    border: Border.all(color: Colors.grey,width: 2),
                                    color: Colors.transparent,
                                  ),
                                  child:
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      FaIcon(FontAwesomeIcons.trashCan,color: Colors.grey,),
                                      Text('  Delete',style: TextStyle(fontSize: 22,color: Colors.grey,fontWeight: FontWeight.w500),),
                                    ],
                                  )),
                            ),

                            InkWell(
                              onTap: ()
                              async {
                                if(amount.text.isNotEmpty&&
                                    title.text.isNotEmpty&&
                                    desc.text.isNotEmpty&&
                                    freq.text.isNotEmpty&&
                                    reminder.text.isNotEmpty
                                )
                                {
                                      var amountr = amount.text.toString();
                                      var titler = title.text.toString();
                                      var descr = desc.text.toString();
                                      var freqr = freq.text.toString();
                                      var reminderr = reminder.text.toString();

                                      SharedPreferences prefbudget = await SharedPreferences.getInstance();
                                      Map<String, dynamic> register =
                                      {
                                        'amount':amountr,
                                        'title':titler,
                                        'decs':descr,
                                        'freq':freqr,
                                        'reminder':reminderr,
                                      };

                                      String encodedbudget = json.encode(register);
                                      prefbudget.setString('budget', encodedbudget);
                                      print(encodedbudget);


                                      var encodedMap = prefbudget.getString('budget');
                                      Map<String,dynamic> decodedMap = json.decode(encodedMap!);
                                      print(decodedMap);


                                      Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => HomePage()
                                          ),
                                          );
                                }
                                else
                                {
                                  Fluttertoast.showToast(
                                    msg: 'Please enter all fields',
                                    toastLength: Toast.LENGTH_SHORT,
                                  );
                                }









                              },
                              child: Container(
                                width: 155,
                                height: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(22),
                                    color: Color(0xff9DAEE2),
                                  ),
                                  child: Center(child: Text('Save',style: TextStyle(fontSize: 22,color: Colors.white,fontWeight: FontWeight.w500),))),
                            ),
                          ],
                        ),
                      ),
                    ),

                  ],
                ),
              ),
            ),




          ],
        ),
      ),




    );
  }
}
