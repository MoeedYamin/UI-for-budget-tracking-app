import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../checklogin.dart';
import 'newbudget.dart';
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  var time = DateTime.now();
  final List budget = [];
  String add = '100';

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      username();

    });
  }

  void addItemToList(){
    setState(() {
      budget.insert(0,add);
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      body:Container(
        color: Color(0xffF8F7F1),
        width: double.infinity,
        height: double.infinity,
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 60.0,left: 20),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [

                              Text('Welcome ',style: TextStyle(fontSize: 24),),
                              // ignore: unnecessary_null_comparison
                             Text(name,style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold,color: Color(0xff9DAEE2)))
                             // else Text('User',style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold,color: Color(0xff9DAEE2))),

                            ],
                          ),
                        ),
                      ),
                      Text('${time.day}-${time.month}-${time.year}',
                        style: TextStyle(fontSize: 18,color: Colors.grey),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 60.0,right: 20),
                    child: FaIcon(FontAwesomeIcons.bell),
                  ),


                ],
              ),

              Padding(
                padding: const EdgeInsets.only(top: 25.0,left: 25,right: 25),
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    width: double.infinity,
                    height: 400,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0,left: 10),
                            child: Container(
                                alignment: Alignment.topLeft,
                                child: Text('Monthly Balance',style: TextStyle(fontSize: 20),)),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 20.0,left: 25,right: 2),
                            child: Row(
                              children: [
                                FaIcon(FontAwesomeIcons.dollar),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child:
                                  (balance!=null)?
                                  Text(balance,style: TextStyle(fontSize: 23,fontWeight: FontWeight.w600),):
                                  Text("Your Balance",style: TextStyle(fontSize: 23,fontWeight: FontWeight.w600),),
                                )
                              ],
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top: 25.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Container(
                                      width: 140,
                                      height: 190,
                                      color: Color(0xffF8F7F1),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Container(
                                      width: 140,
                                      height: 190,
                                      color: Color(0xffF8F7F1),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top: 28.0,left: 10),
                            child: InkWell(
                              onTap: ()
                              {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => NewBudget()),
                                );
                              },
                              child: Container(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: Colors.grey,
                                          width: 1
                                      )
                                  ),
                                  width: 130,
                                  height: 40,
                                  child: Center(child: Text('+   New Budget',style: TextStyle(fontSize: 15),)),

                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.only(top: 18.0,left: 35,right: 35),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Budget Overview',style: TextStyle(fontSize: 21),),
                    Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: Colors.grey)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(6.0),
                        child: InkWell(
                            onTap: ()
                            {
                              print("Abcd");
                              addItemToList();
                            },
                            child: FaIcon(FontAwesomeIcons.plus,color: Colors.black87,)),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(
                height: 300,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListView.builder(
                    itemCount: budget.length,
                    itemBuilder: (BuildContext context, int index){
                      return Padding(
                        padding: const EdgeInsets.only(left: 35.0,right: 35,bottom: 20),
                        child: Container(
                          height: 95,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 15.0,top: 12),
                                    child: Text('Activity',style: TextStyle(color: Colors.grey,fontSize: 17),),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 15.0, top: 12),
                                    child: Text('${time.day}-${time.month}-${time.year}',
                                      style: TextStyle(fontSize: 18,color: Colors.grey),
                                    ),
                                  ),

                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 15.0,top: 15),
                                    child: Text('Community Lunch',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 15.0,top: 15),
                                    child: Row(
                                      children: [
                                        FaIcon(FontAwesomeIcons.dollarSign),
                                        Text('${budget[index]}',style: TextStyle(fontSize: 20),)
                                      ],
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      );


                    },
                  ),
                ),
              ),

            ],
          ),
        ),

      ),

    );
  }
  // username() async
  // {
  //   var prefname = await SharedPreferences.getInstance();
  //   var encodedMap = prefname.getString('registered');
  //   Map<String,dynamic> decodedMap = json.decode(encodedMap!);
  //   name=decodedMap['name'];
  //
  //   var prefbalance = await SharedPreferences.getInstance();
  //   var encodedMapbalance = prefbalance.getString('budget');
  //   Map<String,dynamic> decodedMapbalance = json.decode(encodedMapbalance!);
  //   balance=decodedMapbalance['amount'];
  //
  //   setState(() {
  //
  //   });
  //
  //
  //
  //
  //
  // }

}

