import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Notifications extends StatefulWidget {
  const Notifications({super.key});

  @override
  State<Notifications> createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  var arrNames = ['Abcd','Bcde','Cdef','Defg','Efgh','Fghi','Ghij'];
  var time = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: false,
          backgroundColor: Colors.transparent,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: FaIcon(FontAwesomeIcons.bell,color: Colors.black,),
              ),
              Text('Notifications',style: TextStyle(color: Colors.black,fontSize: 22),),
            ],
          ),

          ),

      body: Padding(
        padding: const EdgeInsets.only(top: 30.0),
        child: Container(
          color: Color(0xffF8F7F1),
          child: ListView.builder(itemBuilder: (context, index) {
            return ListTile(
              // leading: Text('${index+1}'),
              leading: Container(
                width: 60,
                height: 60,
                child: CircleAvatar(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(100),


                    ),
                     ),
                ),
              ),
              title: Text(arrNames[index]),
              subtitle: Text('Message'),
              trailing: Text('${time.day}-${time.month}-${time.year}',
                style: TextStyle(fontSize: 12,color: Colors.grey),
              ),
            );
          },
            padding: EdgeInsets.all(20.0),
            itemCount: arrNames.length,
            scrollDirection: Axis.vertical,

          ),
        ),
      ),
    );
  }
}
