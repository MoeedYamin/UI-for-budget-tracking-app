import 'package:dompet/register.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
class LogoutPage extends StatefulWidget {
  const LogoutPage({super.key});

  @override
  State<LogoutPage> createState() => _LogoutPageState();
}

class _LogoutPageState extends State<LogoutPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffF8F7F1),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(left: 25,right: 25),
          child: Container(
            width: double.infinity,
            height: 280,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 18.0,left: 10,bottom: 5),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Are you sure?',style: TextStyle(fontSize: 24,fontWeight: FontWeight.w500),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 10.0,right: 10),
                  child: Divider(
                    color: Colors.grey.shade400,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 32.0,left: 12,right: 30),
                  child: Text.rich(
                    TextSpan(
                      text: 'This action ',style: TextStyle(fontSize: 17),
                      children:[
                        TextSpan(text: 'cannot ', style: TextStyle(fontSize: 17,color: Color(0xff9DAEE2)),
                        ),
                        TextSpan(text: 'be undone. You will have to login again. Whould you like to continue?', style: TextStyle(fontSize: 17),
                        ),
                      ],
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 40,right: 5,left: 5),
                  child: InkWell(
                    onTap: ()
                    async {
                      var preflogincheck = await SharedPreferences.getInstance();
                      preflogincheck.setBool('login', false);

                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => RegisterPage()
                          ),
                          ModalRoute.withName("/Register")
                      );

                    },
                    child: Container(
                      width: double.infinity,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Color(0xff9DAEE2),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Center(child: Text('Yes, Logout',style: TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.w500),)),
                    ),
                  ),
                )


              ],
            ),
          ),
        ),
      ),

    );
  }
}
