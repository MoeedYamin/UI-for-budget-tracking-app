import 'package:dompet/Screens/settings/editprofile.dart';
import 'package:dompet/checklogin.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';


class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  var eye=true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    username();
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
        title: Text('Profile',style: TextStyle(color: Colors.black,fontSize: 22),),
        centerTitle: true,
        actions: <Widget>[
        IconButton(

          icon: InkWell(
            onTap: ()
            {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => EditProfile()),
              );
            },
            child: FaIcon(
            FontAwesomeIcons.edit,
            size: 23,
            ),
          ),
          onPressed: ()
          {

          },
      ),
    ]
    ),

      body:
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                SizedBox(
                  height: 20,
                ),

                CircleAvatar(
                  maxRadius: 70,
                  backgroundColor: Colors.blue.shade100,
                  child: FaIcon(FontAwesomeIcons.person,
                    color: Colors.black,
                    size: 80,
                  ),
                ),

                SizedBox(
                  height: 30,
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 0),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Name',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black54),)),
                ),


                Padding(
                  padding: const EdgeInsets.only(left: 20.0,right: 20,top: 8,bottom: 5),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(width: 0,color: Colors.black12),
                      color: Colors.grey.shade100,
                    ),
                    height: 59,
                    width: double.infinity,

                    child: Container(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 15.0),
                          child: Text(name,style: TextStyle(fontSize: 18,color: Colors.black),),
                        )),
                  ),


                ),


                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 10),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Email ID',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 20.0,right: 20,top: 8,bottom: 5),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(width: 0,color: Colors.black12),
                      color: Colors.grey.shade100,
                    ),
                    height: 59,
                    width: double.infinity,

                    child: Container(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 15.0),
                          child: Text(email,style: TextStyle(fontSize: 18,color: Colors.black),),
                        )),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 10),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Phone No.',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black54),)),
                ),


                Padding(
                  padding: const EdgeInsets.only(left: 20.0,right: 20,top: 8,bottom: 5),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(width: 0,color: Colors.black12),
                      color: Colors.grey.shade100,
                    ),
                    height: 59,
                    width: double.infinity,

                    child: Container(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 15.0),
                          child: Text(phone,style: TextStyle(fontSize: 18,color: Colors.black),),
                        )),
                  ),


                ),

                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 10),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Password',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black54),)),
                ),


                Padding(
                  padding: const EdgeInsets.only(left: 20.0,right: 20,top: 8,bottom: 5),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(width: 0,color: Colors.black12),
                      color: Colors.grey.shade100,
                    ),
                    height: 59,
                    width: double.infinity,

                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 15.0),
                              child:
                              (eye!=true)?
                              Text(password,style: TextStyle(fontSize: 18,color: Colors.black),):
                              Text('**********',style: TextStyle(fontSize: 18,color: Colors.black),),
                            )),
                        Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: InkWell(
                              onTap: ()
                              {
                                print('clicked');
                                if(eye==false){
                                  eye=true;
                                }
                                else
                                  {
                                    eye=false;
                                  }

                                setState(() {

                                });
                                },
                              child: FaIcon(
                                  FontAwesomeIcons.eyeLowVision
                              )
                          ),
                        )
                      
                      
                      ],
                    ),
                  ),


                ),



                // Padding(
                //   padding: const EdgeInsets.only(left: 22,right: 22,top: 30),
                //   child: Container(
                //     height: 60,
                //     decoration: BoxDecoration(
                //       color: Color(0xff9DAEE2),
                //       borderRadius: BorderRadius.circular(25),
                //     ),
                //     child: Center(
                //         child: Text('Continue'
                //           ,style: TextStyle(fontSize: 22,color: Colors.white,fontWeight: FontWeight.w500),
                //         )),
                //   ),
                // ),




              ],

      ),
          ),






    );
  }
}
