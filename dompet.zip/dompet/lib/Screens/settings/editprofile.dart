import 'dart:convert';

import 'package:dompet/Screens/settings/profile.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../checklogin.dart';
import '../settings.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController pass = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    username();
    setState(() {

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffF8F7F1),
      appBar: AppBar(
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
        title: Text('Edit your profile',style: TextStyle(color: Colors.black,fontSize: 22),),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [


            Container(
              color: Color(0xffF8F7F1),
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(
                  children: [

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Name',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        onChanged: (title)
                        {
                          setState(() {

                          });
                        },
                        controller: name,
                        cursorColor: Colors.black,
                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Enter name',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),


                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Email ID',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        controller: email,
                        cursorColor: Colors.black,
                        onChanged: (desc)
                        {
                          setState(() {

                          });
                        },

                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Enter email',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),


                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Phone No.',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        keyboardType: TextInputType.number,
                        controller: phone,
                        cursorColor: Colors.black,
                        onChanged: (freq)
                        {
                          setState(() {

                          });
                        },

                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Enter phone number',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),


                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 18.0,top: 15),
                      child: Container(
                          alignment: Alignment.topLeft,
                          child: Text('Password',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 15.0,right: 15,top: 5,bottom: 5),
                      child: TextField(
                        controller: pass,
                        cursorColor: Colors.black,
                        onChanged: (reminder)
                        {
                          setState(() {

                          });
                        },

                        style: TextStyle(color: Colors.black,fontSize: 18),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent,),
                            borderRadius: BorderRadius.circular(24),

                          ),
                          hintText: '  Enter password',
                          fillColor: Colors.white,
                          filled: true,
                          hintStyle: TextStyle(fontSize: 18,color: Colors.grey,fontWeight: FontWeight.w500),
                        ),),
                    ),




                      Padding(
                      padding: const EdgeInsets.only(top: 35.0,left: 20,right: 20,bottom: 40),
                      child: InkWell(
                        onTap: ()
                        async {
                          SharedPreferences prefedit = await SharedPreferences.getInstance();
                          if(name.text.isNotEmpty&&
                              email.text.isNotEmpty&&
                              phone.text.isNotEmpty&&
                              pass.text.isNotEmpty
                              )
                            {
                              var encodedMap = prefedit.getString('registered');
                              Map<String,dynamic> decodedMap = json.decode(encodedMap!);

                              if(pass.text.length>7)
                                {
                                Map<String, dynamic> registeredit =
                                {
                                'name':name.text,
                                'email':email.text,
                                'phn':phone.text,
                                'pass':pass.text,
                                'confpass':pass.text,
                                };
                                String encodedregister = json.encode(registeredit);
                                prefedit.setString('registered', encodedregister);

                                setState(() {

                                });

                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => Settings()),
                                  );

                                  print(decodedMap);

                                }
                              else
                                {
                                  Fluttertoast.showToast(
                                    msg: 'Password must contain 8 digits',
                                    toastLength: Toast.LENGTH_SHORT,
                                  );
                                }

                            }
                          else
                          {
                            Fluttertoast.showToast(
                              msg: 'Please enter all fields',
                              toastLength: Toast.LENGTH_SHORT,
                            );
                          }



                        },
                        child: Container(
                          width: double.infinity,
                          height: 55,
                          decoration: BoxDecoration(
                            color: Color(0xff9DAEE2),
                            borderRadius: BorderRadius.circular(22),
                          ),
                          child:
                          Center(
                              child: Text('Continue',style: TextStyle(fontSize: 22,color: Colors.white,fontWeight: FontWeight.w500),)),
                        ),
                      ),
                    ),



                  ],
                ),
              ),
            ),




          ],
        ),
      ),




    );
  }
}
