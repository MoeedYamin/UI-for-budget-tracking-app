import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter/material.dart';
import 'login.dart';
import 'package:shared_preferences/shared_preferences.dart';


class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController phn = TextEditingController();
  TextEditingController pass = TextEditingController();
  TextEditingController confpass = TextEditingController();
  bool invisible = false;
  bool invisible1 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFEFEFF),

      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,

              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 80.0),
                  child: Image.asset('assets/images/logo.png'),
                ),

                Text('Create an Account',style: TextStyle(fontSize: 22,fontWeight: FontWeight.w500),),
                Text('with MYDOMPET',style: TextStyle(fontSize: 21,fontWeight: FontWeight.w500),),

                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 24),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Name',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: name,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                        ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  Eg. John',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                      // border: OutlineInputBorder(
                      //   borderSide: BorderSide(color: Colors.grey),
                      //   borderRadius: BorderRadius.circular(11),
                      // ),
                    ),),


                  ),

                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 14),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Email ID',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: email,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  Enter your email',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                      // border: OutlineInputBorder(
                      //   borderSide: BorderSide(color: Colors.grey),
                      //   borderRadius: BorderRadius.circular(11),
                      // ),
                    ),),


                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,top: 14),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Phone Number',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: phn,
                    keyboardType: TextInputType.number,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  +92',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                      // border: OutlineInputBorder(
                      //   borderSide: BorderSide(color: Colors.grey),
                      //   borderRadius: BorderRadius.circular(11),
                      // ),
                    ),),


                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,top: 14),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Password',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: pass,
                    obscureText: !invisible,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  AtLeast 8 Characters',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                      suffixIcon: GestureDetector(
                          onTap: ()
                          {
                            if (invisible == true) {
                              setState(() {

                                invisible = false;
                              });
                            } else {
                              setState(() {
                                invisible = true;
                              });
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Icon(
                              Icons.remove_red_eye,
                              color: Colors.grey,
                              size: 25,
                            ),
                          )),

                    ),),


                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,top: 14),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Confirm Password',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: confpass,
                    obscureText: !invisible1,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  AtLeast 8 Characters',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                      suffixIcon: GestureDetector(
                          onTap: ()
                          {
                          if (invisible1 == true) {
                                  setState(() {
                                    invisible1 = false;
                                  });
                                } else {
                                  setState(() {
                                    invisible1 = true;
                                  });
                                }
                              },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Icon(
                                Icons.remove_red_eye_outlined,
                              color: Colors.grey,
                              size: 25,
                            ),
                          )),
                    ),),
                ),
                SizedBox(
                  height: 50,
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 17,right: 17),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(25),
                    child: InkWell(
                      onTap: ()
                      async {

                        if(name.text.isNotEmpty&&
                            email.text.isNotEmpty&&
                            pass.text.isNotEmpty&&
                            phn.text.isNotEmpty&&
                            confpass.text.isNotEmpty
                        )
                          {
                            if(pass.text.length>7)
                              {
                                if(pass.text==confpass.text)
                                  {
                                    var namer = name.text.toString();
                                    var emailr = email.text.toString();
                                    var phnr = phn.text.toString();
                                    var passr = pass.text.toString();
                                    var confpassr = confpass.text.toString();

                                    SharedPreferences pref = await SharedPreferences.getInstance();
                                    Map<String, dynamic> register =
                                    {
                                      'name':namer,
                                      'email':emailr,
                                      'phn':phnr,
                                      'pass':passr,
                                      'confpass':confpassr,
                                    };

                                    String encodedregister = json.encode(register);
                                    pref.setString('registered', encodedregister);
                                    print(encodedregister);


                                    var encodedMap = pref.getString('registered');
                                    Map<String,dynamic> decodedMap = json.decode(encodedMap!);
                                    print(decodedMap);

                                    Navigator.pushAndRemoveUntil(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => LoginPage()
                                        ),
                                        ModalRoute.withName("/Login")
                                    );

                                  }
                                else
                                  {
                                    Fluttertoast.showToast(
                                      msg: 'Password doesn\'t match',
                                      toastLength: Toast.LENGTH_SHORT,
                                    );
                                  }

                              }
                            else
                              {
                                Fluttertoast.showToast(
                                  msg: 'Password too short',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              }

                          }


                        else
                        {
                            Fluttertoast.showToast(
                            msg: 'Please enter all fields',
                            toastLength: Toast.LENGTH_SHORT,
                          );
                        }






                      },
                      child: Container(
                        width: double.infinity,
                        height: 58,
                        color: Color(0xff9DAEE2),
                        child: Center(child: Text('Create an account',style: TextStyle(fontSize: 22,color: Colors.white,fontWeight: FontWeight.w500),)),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 14.0),
                  child: InkWell(
                    onTap: ()
                    {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPage()),
                      );
                    },
                    child: Text.rich(
                      TextSpan(
                        text: 'Already have an account? ',style: TextStyle(fontSize: 16),
                        children:[
                          TextSpan(text: 'Login', style: TextStyle(fontSize: 20,color: Color(0xff9DAEE2),fontWeight: FontWeight.w700),
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                SizedBox(
                  height: 70,
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }
}
