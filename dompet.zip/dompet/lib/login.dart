import 'dart:convert';

import 'package:dompet/checklogin.dart';
import 'package:dompet/mainpage.dart';
import 'package:dompet/register.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool invisible = false;
  bool check3 = false;
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFEFEFF),

      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,

              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 90.0),
                  child: Image.asset('assets/images/logo.png'),
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 16.0),
                  child: Text('Log in to continue using',style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold),),
                ),
                Text('MYDOMPET',style: TextStyle(fontSize: 21,fontWeight: FontWeight.bold),),


                Padding(
                  padding: const EdgeInsets.only(left: 18.0,top: 54),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Email ID',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: email,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  Enter your email',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                    ),),


                ),


                Padding(
                  padding: const EdgeInsets.only(left: 15.0,top: 30),
                  child: Container(
                      alignment: Alignment.topLeft,
                      child: Text('Password',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400,color: Colors.black54),)),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 15.0,right: 15,top: 8,bottom: 5),
                  child: TextField(
                    controller: password,
                    obscureText: !invisible,
                    cursorColor: Colors.black,
                    style: TextStyle(color: Colors.black,fontSize: 16),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12, width: 2),
                        borderRadius: BorderRadius.circular(24),

                      ),
                      hintText: '  Enter your password',
                      fillColor: Colors.grey.shade100,
                      filled: true,
                      hintStyle: TextStyle(fontSize: 16,color: Colors.grey),
                      suffixIcon: GestureDetector(
                          onTap: ()
                          {
                            if (invisible == true) {
                              setState(() {
                                invisible = false;
                              });
                            } else {
                              setState(() {
                                invisible = true;
                              });
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Icon(
                              Icons.remove_red_eye,
                              color: Colors.grey,
                              size: 25,
                            ),
                          )),

                    ),),
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 0,right: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [

                      SizedBox(
                        width:210,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: CheckboxListTile(
                            checkColor: Colors.white,
                            checkboxShape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5)),
                            activeColor: Color(0xff9DAEE2),
                            value: check3,
                            controlAffinity: ListTileControlAffinity.leading,
                            onChanged: (bool? value)
                          {
                            setState(() {
                              check3=value!;
                              print(check3);
                            });
                          },
                            title: const Align(
                              alignment: Alignment(-3, 0),
                              child: Text("Remember me",style: TextStyle(color: Colors.black54),),),
                      ),
                        ),
                      ),
                      TextButton(onPressed: (){}, child: Padding(
                        padding: const EdgeInsets.only(right: 9.0),
                        child: Text("Forget password?",style: TextStyle(fontSize: 16,color: Colors.black54),),
                      ))

                    ],
                  ),
                ),
                SizedBox(
                  height: 50,
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 17,right: 17),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(25),
                    child: InkWell(
                      onTap: ()
                      async {
                        SharedPreferences pref = await SharedPreferences.getInstance();
                        if(pref.getString('registered')==null)
                          {
                            print("empty");
                            Fluttertoast.showToast(msg: 'Account does not exist');

                            return;
                          }
                        var encodedMap = pref.getString('registered');
                        Map<String,dynamic> decodedMap = json.decode(encodedMap!);
                        print(decodedMap);
                        if(email.text.isNotEmpty&&
                            password.text.isNotEmpty)
                        {
                          if(email.text==decodedMap['email']&&password.text==decodedMap['pass'])
                              {
                                if(check3==true)
                                {
                                  var preflogincheck = await SharedPreferences.getInstance();
                                  preflogincheck.setBool('login', true);
                                  Fluttertoast.showToast(msg: 'Logged in successfully');
                                  Navigator.pushAndRemoveUntil(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HomePage()
                                      ),
                                      ModalRoute.withName("/Home")
                                  );
                                }
                                else
                                {
                                  print('not saved');
                                  Fluttertoast.showToast(msg: 'Logged in successfully');
                                  Navigator.pushAndRemoveUntil(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HomePage()
                                      ),
                                      ModalRoute.withName("/Home")
                                  );
                                }



                              }
                              else
                              {
                                Fluttertoast.showToast(msg: 'Incorrect email or password');
                              }
                        }
                        else
                        {
                          Fluttertoast.showToast(msg: 'Please enter all fields');
                        }



                      },
                      child: Container(
                        width: double.infinity,
                        height: 58,
                        color: Color(0xff9DAEE2),
                        child: Center(child: Text('Log in',style: TextStyle(fontSize: 22,color: Colors.white,fontWeight: FontWeight.w500),)),
                      ),
                    ),
                  ),
                ),


                Padding(
                  padding:
                  const EdgeInsets.only(left: 10, top: 10, right: 10),
                  child: Container(
                      alignment: Alignment.center,
                      child: Text(
                        "Or",
                        style: TextStyle(fontSize: 21, color: Colors.grey),
                      )),
                ),

                Padding(
                  padding:
                  const EdgeInsets.only(top: 10, left: 17, right: 17),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => RegisterPage()),
                      );
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: double.infinity,
                      height: 58,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: Colors.transparent,
                        border: Border.all(
                            color: Color(0xff9DAEE2),
                            width: 2),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Create an account",
                          style: TextStyle(
                              fontSize: 21,
                            color: Color(0xff9DAEE2),),
                        ),
                      ),
                    ),
                  ),
                ),



                SizedBox(
                  height: 70,
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }

}

