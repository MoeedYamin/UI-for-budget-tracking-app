
import 'package:dompet/checklogin.dart';
import 'package:dompet/register.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'mainpage.dart';
import 'main.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      username();

    });
  }

  @override
  Widget build(BuildContext context) {

    const bool a = true;

    return Scaffold(
      backgroundColor: Color(0xff9DAEE2),
      body: Stack(
        children:[
          Padding(
            padding: const EdgeInsets.only(bottom: 80.0),
            child: Container(
              alignment: Alignment.center,
              width: double.infinity,
              height: double.infinity,
              child: Image.asset('assets/images/Welcome page.png',
              fit: BoxFit.fill),
            ),
          ),
          Positioned(
                bottom: 35,
                right: 35,
                child: InkWell(
                onTap: ()
                  {
                    wheretogo(context);









                      // Navigator.push(
                      // context,
                      //   MaterialPageRoute(builder: (context) => RegisterPage()),
                      //   );
                      },
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Container(
                      color: Colors.black12,
                        width: 50,
                        height: 50,
                        child: Icon(
                            Icons.arrow_forward,
                          color: Colors.white,
                        )),
                  ),
                )),

        ],
      ),



    );


  }

  void wheretogo(BuildContext context) async {

    var preflogincheck = await SharedPreferences.getInstance();

    var isloggedin = preflogincheck.getBool('login');


    if(isloggedin!=null)
    {
      if(isloggedin)
      {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> HomePage()));
      }
      else
        {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> RegisterPage()));
        }
    }
    else
    {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> RegisterPage()));
    }


  }
}
