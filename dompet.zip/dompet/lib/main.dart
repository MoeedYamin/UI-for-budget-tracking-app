import 'package:dompet/welcome.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: 'welcome',
    routes: {
      // 'login':(context)=>MyMainPage()
      // 'login':(context)=>Mylogin()
      'welcome':(context)=>WelcomePage(),
    },
  ));


}
class Check {
  var logincheck= true;
}