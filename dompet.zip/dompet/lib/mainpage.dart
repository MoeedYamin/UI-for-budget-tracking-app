import 'dart:convert';

import 'package:dompet/Screens/settings.dart';
import 'package:dompet/Screens/wallet.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Screens/home.dart';
import 'Screens/notifications.dart';
import 'checklogin.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int myIndex = 0;
  List<Widget> widgetlist = [
    Home(),
    Wallet(),
    Notifications(),
    Settings(),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      username();
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Center(
        child: widgetlist[myIndex],
      ),

      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          onTap: (index)
            {
              setState(() {
                myIndex = index;

              });

            },
            selectedLabelStyle: TextStyle(fontSize: 12),
            unselectedLabelStyle: TextStyle(fontSize: 12),
            currentIndex: myIndex,
            selectedItemColor: Color(0xff9DAEE2),
            unselectedItemColor: Colors.grey,
            showUnselectedLabels: true,
            showSelectedLabels: true,
            items: const[
            BottomNavigationBarItem(
                icon: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: FaIcon(FontAwesomeIcons.home,
                  // color: Color(0xff9DAEE2),
                  ),
                ),
              label: 'Home',


            ),
            BottomNavigationBarItem(
                icon: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: FaIcon(FontAwesomeIcons.wallet,
                  // color: Colors.grey,
                  ),
                ),
                label: 'Monthly Income'

            ),
            BottomNavigationBarItem(
                icon: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: FaIcon(FontAwesomeIcons.bell,
                      // color: Colors.grey
                  ),
                ),
                label: 'Notifications',

            ),
            BottomNavigationBarItem(
                icon: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: FaIcon(FontAwesomeIcons.gear,
                      // color: Colors.grey
                  ),
                ),
                label: 'Settings'

            ),
          ]
          
        ),
      ),
    );
  }
  // username() async
  // {
  //   var prefname = await SharedPreferences.getInstance();
  //   var encodedMap = prefname.getString('registered');
  //   Map<String,dynamic> decodedMap = json.decode(encodedMap!);
  //   name=decodedMap['name'];
  //
  //   var prefbalance = await SharedPreferences.getInstance();
  //   var encodedMapbalance = prefbalance.getString('budget');
  //   Map<String,dynamic> decodedMapbalance = json.decode(encodedMapbalance!);
  //   balance=decodedMapbalance['amount'];
  //
  //   setState(() {
  //
  //   });
  //
  //
  //
  //
  //
  // }

}
