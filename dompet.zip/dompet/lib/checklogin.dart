import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

var checklogin = true;
var check;
var checkloginfalse = false;

var name;
var balance;
var email;
var password;
var phone;

username() async
{
  var prefname = await SharedPreferences.getInstance();
  var encodedMap = prefname.getString('registered');
  Map<String,dynamic> decodedMap = json.decode(encodedMap!);
  name=decodedMap['name'];
  email=decodedMap['email'];
  password=decodedMap['pass'];
  phone=decodedMap['phn'];

  var prefbalance = await SharedPreferences.getInstance();
  var encodedMapbalance = prefbalance.getString('budget');
  Map<String,dynamic> decodedMapbalance = json.decode(encodedMapbalance!);
  balance=decodedMapbalance['amount'];







}

