package com.example.dompet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
